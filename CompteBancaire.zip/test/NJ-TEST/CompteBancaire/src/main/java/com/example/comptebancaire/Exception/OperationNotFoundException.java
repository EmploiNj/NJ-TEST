package com.example.comptebancaire.Exception;

public class OperationNotFoundException extends RuntimeException{
   public OperationNotFoundException(Long id){

    }
}
