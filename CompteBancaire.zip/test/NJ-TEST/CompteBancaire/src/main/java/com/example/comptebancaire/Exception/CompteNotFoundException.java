package com.example.comptebancaire.Exception;

public class CompteNotFoundException extends RuntimeException{
    public CompteNotFoundException (Long id){

    }
}
