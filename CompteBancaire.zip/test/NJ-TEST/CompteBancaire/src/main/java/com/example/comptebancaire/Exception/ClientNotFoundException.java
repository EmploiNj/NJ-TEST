package com.example.comptebancaire.Exception;

public class ClientNotFoundException extends RuntimeException {
      public  ClientNotFoundException(Long id){

        }
}
